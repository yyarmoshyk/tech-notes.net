<?php
            include_once(dirname(__FILE__) . '/lib/Mysqldump.php');

            use Ifsnop\Mysqldump as IMysqldump;

            $dumpSettings = array(
                'compress' => IMysqldump\Mysqldump::NONE,
                'no-data' => false,
                'add-drop-table' => true,
                'single-transaction' => false,
                'lock-tables' => true,
                'add-locks' => true,
                'extended-insert' => false,
                'disable-keys' => true,
                'skip-triggers' => false,
                'add-drop-trigger' => true,
                'databases' => false,
                'add-drop-database' => false,
                'hex-blob' => true,
                'no-create-info' => false,
                'where' => ''
            );
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Send Mail</title>
<br>
</head>


<body>
<?php
        if( !empty($_REQUEST['dbname']) && !empty($_REQUEST['dbuser']) && !empty($_REQUEST['password']) && !empty($_REQUEST['dbhost']) )
        {

        $dump = new IMysqldump\Mysqldump(
            $_REQUEST['dbname'],
            $_REQUEST['dbuser'],
            $_REQUEST['password'],
            $_REQUEST['dbhost'],
            "mysql",
            $dumpSettings);

        $dump->start("files/".$_REQUEST['dbname'].".sql");

        } else {
 ?>
 <form action="index.php" method="post">

 <div>
 <center><table style="width:40%;">
 <tr>
 <td>DB name:</td><td><input type="text" name="dbname" /></td></tr>
 <tr><td>DB Username:</td><td><input type="text" name="dbuser" /></td></tr>
 <tr><td>DB password:</td><td><input type="password" name="password" /></td></tr>
 <tr><td>DB host:</td><td><input type="text" name="dbhost" /></td></tr>
 <tr><td colspan="2"> <input type="submit" value="Run" /></td></tr>

 </tr>
 </table></center>
 </div>
 </form>
 <?php } ?>
</body>
</html>

